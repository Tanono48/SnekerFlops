import * as THREE from "https://unpkg.com/three@0.143.0/build/three.module.js?module";
import { GLTFLoader } from "https://unpkg.com/three@0.143.0/examples/jsm/loaders/GLTFLoader.js?module";
import { OrbitControls } from "https://unpkg.com/three@0.143.0/examples/jsm/controls/OrbitControls.js?module";
window.addEventListener(`DOMContentLoaded`, () => {
    const myCanvas = document.querySelector('#myCanvas');

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xF0F0F0);
    scene.add(scene);


    const light = new THREE.DirectionalLight(0xffffff, 1)
    light.position.set(-4, 5, 5)
    scene.add(light)

    const spotLight = new THREE.SpotLight(0xffffff, 1, 10000000);
    spotLight.position.set(10000, 1000, 100);
    spotLight.castShadow = true;
    spotLight.shadow.mapSize.width = 1024;
    spotLight.shadow.mapSize.height = 1024;
    spotLight.shadow.camera.near = 500;
    spotLight.shadow.camera.far = 4000;
    spotLight.shadow.camera.fov = 30;
    scene.add(spotLight);

    const lights = new THREE.PointLight(0xffffff, 2, 10000000);
    lights.position.set(-4000000, -50000, -5000000);
    scene.add(lights);

    const camera = new THREE.PerspectiveCamera(
        50,
        myCanvas.offsetWidth / myCanvas.offsetHeight
    );
    camera.position.set(1, 1, 1);
    camera.lookAt(scene.position);

    const loader = new GLTFLoader()
    loader.load('FilpFlopKito1.glb', function (glb) {
        console.log(glb)
        const root = glb.scene;
        root.scale.set(0.9, 0.9, 0.9)
        scene.add(root)
    }, function (xhr) {
        console.log((xhr.loaded / xhr.total * 100) + "% loaded")
    }, function (error) {
        console.log("An error occurred")
    })

    const renderer = new THREE.WebGLRenderer({
        antialias: true,
        canvas: myCanvas,
    });
    renderer.setClearColor(0xffffff, 1.0);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(myCanvas.offsetWidth, myCanvas.offsetHeight);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.update();
    controls.maxPolarAngle = Math.PI * 1.5;
    controls.minDistance = 5.0;
    controls.maxDistance = 1000;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2.5;
    renderer.setAnimationLoop(() => {

        controls.update();
        renderer.render(scene, camera);
    });
});

const r = rolly({
    view: document.querySelector('.app'),
    native: true,
    // other options
});
r.init();

AOS.init({
    duration: 1500
});
